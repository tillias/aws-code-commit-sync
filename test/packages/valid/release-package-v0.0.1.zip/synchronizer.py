class Synchronizer:
    def foo(self):
        print('Synchronizer ready to serve')
